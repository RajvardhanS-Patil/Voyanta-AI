---
name: Cloud Glass
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#4a4455'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#7b7487'
  outline-variant: '#ccc3d8'
  surface-tint: '#732ee4'
  primary: '#630ed4'
  on-primary: '#ffffff'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#d2bbff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#4c4f51'
  on-tertiary: '#ffffff'
  tertiary-container: '#646769'
  on-tertiary-container: '#e4e6e8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style
The design system is anchored in a philosophy of "Atmospheric Precision." It targets a high-end demographic that values clarity, technological sophistication, and executive-level calm. The aesthetic blends **Minimalism** with **Glassmorphism**, creating a UI that feels less like a digital tool and more like a physical pane of glass suspended in a bright, airy environment.

The emotional response should be one of immediate trust and cognitive ease. By using expansive whitespace and translucent layering, the design system eliminates visual noise, allowing the user to focus on high-value AI insights. It is sophisticated, "expensive," and intentionally understated.

## Colors
The palette is dominated by a foundational "Cloud" background, providing a luminous stage for the content. 

- **Primary Background**: #F8FAFC. This creates a soft, off-white environment that reduces eye strain compared to pure white.
- **Primary Accent (Deep Lavender)**: Used for high-priority actions and brand-led moments. It represents the "intelligence" of the AI.
- **Secondary Accent (Cyber Teal)**: Reserved for success states, data visualizations, and secondary highlights.
- **Surfaces**: Pure White (#FFFFFF) at various opacities (80-95%) to enable the glass effect.
- **Borders**: #E2E8F0. A subtle, low-contrast stroke that defines edges without adding visual weight.

## Typography
The typography strategy creates a clear hierarchy between brand expression and functional utility. 

**Outfit** is used for all headings to provide a modern, geometric, and bold personality. It should be set with tight letter-spacing in larger sizes to maintain a premium "editorial" feel. 

**Inter** is the workhorse for all body text, data, and interface labels. Its neutral, highly legible glyphs ensure that complex information remains accessible. Use `body-md` as the default for standard text blocks. All labels should utilize the `label-bold` style for metadata or category tags to create clear visual anchors.

## Layout & Spacing
This design system utilizes an **8pt Grid System** to ensure mathematical harmony across all components. 

- **Grid Model**: A 12-column fluid grid for desktop with a maximum container width of 1280px. 
- **Gutters & Margins**: 24px (3 units) for desktop gutters to maintain the "airy" feel. On mobile, margins reduce to 16px (2 units).
- **Rhythm**: Vertical rhythm is strictly enforced in multiples of 8px. Use 48px or 64px for section spacing to emphasize the "minimal" and spacious aesthetic.
- **Alignment**: Center-aligned containers for marketing/landing pages; left-aligned fluid layouts for dashboard and data-heavy views.

## Elevation & Depth
Depth is created through **Ambient, Multi-layered Shadows** and **Backdrop Blurs**, rather than heavy borders or dark fills.

- **Surface Treatment**: Primary cards use a white fill at 90% opacity with a `backdrop-filter: blur(12px)`.
- **Shadow Stack**: To achieve the "expensive" look, use at least three shadow layers:
    1. A very soft, wide-cast base: `0px 20px 50px rgba(0, 0, 0, 0.04)`
    2. A tighter mid-level: `0px 10px 15px rgba(0, 0, 0, 0.03)`
    3. A crisp 1px definition: `0px 1px 2px rgba(0, 0, 0, 0.02)`
- **Interaction**: On hover, elements should subtly "lift" by increasing the blur radius of the shadow and decreasing the opacity of the glass surface to 95%.

## Shapes
The shape language is generous and friendly, utilizing large radii to soften the technical nature of AI.

- **Cards/Containers**: Fixed at **24px** (rounded-xl) to create a soft, welcoming frame for content.
- **Buttons/Inputs**: Fixed at **18px** (rounded-lg) to provide a distinct "pill-like" but structured feel.
- **Small Elements**: Tags and tooltips use **8px** (rounded-sm) to maintain consistency without appearing overly circular at small scales.

## Components
Consistent implementation of the following components is vital to maintaining the "Cloud Glass" aesthetic:

- **Buttons**:
    - *Primary*: Deep Lavender (#7C3AED) fill, white text, 18px radius. Subtle inner-glow top-border (1px, white, 20% opacity).
    - *Glass*: White (20% opacity), backdrop-blur(8px), 1px border (#E2E8F0), 18px radius.
- **Cards**: Pure white at 90% opacity, 1px border in #E2E8F0, 24px radius. No internal dividers; use whitespace (32px padding) to separate content sections.
- **Input Fields**: 1px border #E2E8F0, 18px radius, white fill. On focus, the border transitions to Deep Lavender with a 4px soft glow (shadow).
- **Chips/Tags**: Small 8px radius, #F1F5F9 background, Deep Lavender text.
- **Lists**: Clean lines with 1px #F1F5F9 bottom-borders. Avoid zebra-striping; use hover-states with a 50% opacity white fill to highlight rows.
- **AI Signature**: Components powered by AI should feature a subtle gradient border using the Primary and Secondary accents (Lavender to Teal) to differentiate them from standard UI.